When project is updated
- Check if `trickle/notes/README.md` needs to be updated to reflect new features or file structure changes.
- Keep the language of README consistent with the project (Hindi/English mix in this case).